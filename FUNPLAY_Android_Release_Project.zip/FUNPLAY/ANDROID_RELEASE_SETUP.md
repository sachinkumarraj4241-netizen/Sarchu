# FUNPLAY Android Release Setup

This project now includes the Android/Gradle scaffold needed for a Flutter Android build.

## Package ID
`com.funplay.app`

If this ID is already used on Google Play, change `applicationId` in `android/app/build.gradle` before the first Play Store upload. Once published, the application ID cannot be changed for that app.

## Mobile-only cloud build
A GitHub Actions workflow is included at `.github/workflows/android-aab.yml`.

Add these GitHub Actions repository secrets:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Then open **Actions → FUNPLAY Android AAB → Run workflow**. The signed AAB will appear under the workflow run's Artifacts if the signing secrets are correct.

## Important
Never commit `key.properties`, `.jks`, `.keystore`, passwords, or private keys to GitHub.

The included workflow is a build helper. It does not publish the app to Google Play automatically.
