create extension if not exists "pgcrypto";

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null,
 full_name text default '',
 avatar_url text,
 bio text default '',
 created_at timestamptz default now()
);

create table if not exists public.posts (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 caption text default '',
 image_url text,
 created_at timestamptz default now()
);

create table if not exists public.post_likes (
 id uuid primary key default gen_random_uuid(),
 post_id uuid references public.posts(id) on delete cascade,
 user_id uuid references public.profiles(id) on delete cascade,
 unique(post_id,user_id)
);

create table if not exists public.comments (
 id uuid primary key default gen_random_uuid(),
 post_id uuid references public.posts(id) on delete cascade,
 user_id uuid references public.profiles(id) on delete cascade,
 content text not null,
 created_at timestamptz default now()
);

create table if not exists public.chat_rooms (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 description text default '',
 room_type text default 'public',
 created_by uuid references public.profiles(id) on delete cascade,
 created_at timestamptz default now()
);

create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(),
 room_id uuid references public.chat_rooms(id) on delete cascade,
 user_id uuid references public.profiles(id) on delete cascade,
 content text not null,
 created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.post_likes enable row level security;
alter table public.comments enable row level security;
alter table public.chat_rooms enable row level security;
alter table public.messages enable row level security;

-- Drop/recreate policies so this script can be safely re-run during setup.
do $$ declare p record; begin
  for p in select policyname, tablename from pg_policies where schemaname='public' and tablename in ('profiles','posts','post_likes','comments','chat_rooms','messages') loop
    execute format('drop policy if exists %I on public.%I', p.policyname, p.tablename);
  end loop;
end $$;

create policy "profiles_select" on public.profiles for select using (true);
create policy "profiles_insert" on public.profiles for insert with check (auth.uid()=id);
create policy "profiles_update" on public.profiles for update using (auth.uid()=id);
create policy "posts_select" on public.posts for select using (true);
create policy "posts_insert" on public.posts for insert with check (auth.uid()=user_id);
create policy "posts_delete" on public.posts for delete using (auth.uid()=user_id);
create policy "likes_select" on public.post_likes for select using (true);
create policy "likes_insert" on public.post_likes for insert with check (auth.uid()=user_id);
create policy "likes_delete" on public.post_likes for delete using (auth.uid()=user_id);
create policy "comments_select" on public.comments for select using (true);
create policy "comments_insert" on public.comments for insert with check (auth.uid()=user_id);
create policy "rooms_select" on public.chat_rooms for select using (true);
create policy "rooms_insert" on public.chat_rooms for insert with check (auth.uid()=created_by);
create policy "rooms_delete" on public.chat_rooms for delete using (auth.uid()=created_by);
create policy "messages_select" on public.messages for select using (true);
create policy "messages_insert" on public.messages for insert with check (auth.uid()=user_id);

-- Storage: create a PUBLIC bucket named `posts` in Supabase Dashboard.
-- Then add Storage policies appropriate for your production security model.
-- Realtime: enable replication for public.messages in Supabase Dashboard.
