import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const FunPlayApp());
}

class FunPlayApp extends StatelessWidget {
  const FunPlayApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'FUNPLAY',
    theme: ThemeData(
      useMaterial3: true, brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF08080D),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
    ),
    home: supabaseUrl.isEmpty ? const SetupScreen() : const AuthGate(),
  );
}

class SetupScreen extends StatelessWidget {
  const SetupScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(
    body: Center(child: Padding(
      padding: EdgeInsets.all(24),
      child: Text('FUNPLAY\n\nAdd SUPABASE_URL and SUPABASE_ANON_KEY using --dart-define before running the app.',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
    )),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (_, __) => Supabase.instance.client.auth.currentSession == null
          ? const LoginScreen() : const MainShell(),
    );
  }
}

InputDecoration deco(String hint, IconData icon) => InputDecoration(
  hintText: hint, prefixIcon: Icon(icon), filled: true,
  fillColor: const Color(0xFF171722),
  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
);

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final e=TextEditingController(), p=TextEditingController(); bool loading=false;
  Future<void> login() async {
    setState(()=>loading=true);
    try { await Supabase.instance.client.auth.signInWithPassword(email:e.text.trim(),password:p.text); }
    catch(x){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$x'))); }
    if(mounted) setState(()=>loading=false);
  }
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(
    padding:const EdgeInsets.all(24),child:Column(children:[
      const Icon(Icons.play_circle_fill_rounded,size:90,color:Color(0xFF9D7BFF)),
      const Text('FUNPLAY',style:TextStyle(fontSize:36,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),const Text('Connect • Chat • Play • Enjoy'),
      const SizedBox(height:40),TextField(controller:e,decoration:deco('Email',Icons.email)),
      const SizedBox(height:14),TextField(controller:p,obscureText:true,decoration:deco('Password',Icons.lock)),
      const SizedBox(height:24),SizedBox(width:double.infinity,height:52,child:ElevatedButton(
        onPressed:loading?null:login,child:Text(loading?'PLEASE WAIT':'LOGIN'))),
      TextButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const SignupScreen())),
        child:const Text('Create new account'))
    ])))) ;
}

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});
  @override State<SignupScreen> createState()=>_SignupScreenState();
}
class _SignupScreenState extends State<SignupScreen>{
  final n=TextEditingController(),u=TextEditingController(),e=TextEditingController(),p=TextEditingController(); bool loading=false;
  Future<void> signup() async{
    setState(()=>loading=true);
    try{
      final r=await Supabase.instance.client.auth.signUp(email:e.text.trim(),password:p.text,
        data:{'username':u.text.trim(),'full_name':n.text.trim()});
      if(r.user!=null) await Supabase.instance.client.from('profiles').upsert({
        'id':r.user!.id,'username':u.text.trim(),'full_name':n.text.trim()});
      if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Account created. Check email if confirmation is enabled.')));Navigator.pop(context);}
    }catch(x){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$x')));}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Create Account')),body:Padding(
    padding:const EdgeInsets.all(24),child:ListView(children:[
      TextField(controller:n,decoration:deco('Full name',Icons.person)),
      const SizedBox(height:12),TextField(controller:u,decoration:deco('Username',Icons.alternate_email)),
      const SizedBox(height:12),TextField(controller:e,decoration:deco('Email',Icons.email)),
      const SizedBox(height:12),TextField(controller:p,obscureText:true,decoration:deco('Password',Icons.lock)),
      const SizedBox(height:24),ElevatedButton(onPressed:loading?null:signup,child:Text(loading?'CREATING...':'CREATE ACCOUNT'))
    ])));
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell>{
  int i=0;
  final pages=const [FeedScreen(),GamesScreen(),CreatePostScreen(),RoomsScreen(),ProfileScreen()];
  @override Widget build(BuildContext c)=>Scaffold(
    body:pages[i],
    bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(v)=>setState(()=>i=v),destinations:const[
      NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
      NavigationDestination(icon:Icon(Icons.sports_esports),label:'Games'),
      NavigationDestination(icon:Icon(Icons.add_circle_outline),label:'Create'),
      NavigationDestination(icon:Icon(Icons.forum_outlined),label:'Rooms'),
      NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile'),
    ]));
}

class FeedScreen extends StatefulWidget { const FeedScreen({super.key}); @override State<FeedScreen> createState()=>_FeedScreenState(); }
class _FeedScreenState extends State<FeedScreen>{
  Future<List<Map<String,dynamic>>> load()=>Supabase.instance.client.from('posts').select('*, profiles(username,avatar_url)').order('created_at',ascending:false);
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('FUNPLAY')),body:FutureBuilder(
    future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final posts=s.data!;
    return RefreshIndicator(onRefresh:()=>Future.delayed(const Duration(milliseconds:300),()=>setState((){})),child:ListView.builder(
      itemCount:posts.length,itemBuilder:(c,x){final p=posts[x]; final pr=p['profiles']??{};
      return Card(margin:const EdgeInsets.all(10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(pr['username']??'FUNPLAY User')),
        if(p['image_url']!=null) Image.network(p['image_url'],width:double.infinity,height:300,fit:BoxFit.cover),
        Padding(padding:const EdgeInsets.all(12),child:Text(p['caption']??'')),
        Row(children:[IconButton(onPressed:()=>like(p['id']),icon:const Icon(Icons.favorite_border)),IconButton(onPressed:()=>comments(p['id']),icon:const Icon(Icons.comment_outlined))])
      ]));});}));
  Future<void> like(String id) async{final u=Supabase.instance.client.auth.currentUser!;final q=await Supabase.instance.client.from('post_likes').select('id').eq('post_id',id).eq('user_id',u.id).maybeSingle();if(q==null){await Supabase.instance.client.from('post_likes').insert({'post_id':id,'user_id':u.id});}else{await Supabase.instance.client.from('post_likes').delete().eq('id',q['id']);}setState((){});}
  void comments(String id)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CommentsScreen(postId:id)));
}

class CreatePostScreen extends StatefulWidget { const CreatePostScreen({super.key}); @override State<CreatePostScreen> createState()=>_CreatePostScreenState(); }
class _CreatePostScreenState extends State<CreatePostScreen>{
  File? img; final cap=TextEditingController(); bool loading=false;
  Future<void> pick()async{final x=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:80);if(x!=null)setState(()=>img=File(x.path));}
  Future<void> post()async{setState(()=>loading=true);try{String? url;if(img!=null){final u=Supabase.instance.client.auth.currentUser!;final path='${u.id}/${DateTime.now().millisecondsSinceEpoch}.jpg';await Supabase.instance.client.storage.from('posts').upload(path,img!);url=Supabase.instance.client.storage.from('posts').getPublicUrl(path);}await Supabase.instance.client.from('posts').insert({'user_id':Supabase.instance.client.auth.currentUser!.id,'caption':cap.text.trim(),'image_url':url});if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Posted!')));}catch(x){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$x')));}if(mounted)setState(()=>loading=false);}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Create Post')),body:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
    GestureDetector(onTap:pick,child:Container(height:240,width:double.infinity,color:const Color(0xFF171722),child:img==null?const Icon(Icons.add_a_photo,size:60):Image.file(img!,fit:BoxFit.cover))),
    const SizedBox(height:16),TextField(controller:cap,maxLines:4,decoration:deco('Write caption...',Icons.edit)),const SizedBox(height:16),
    ElevatedButton(onPressed:loading?null:post,child:Text(loading?'POSTING...':'PUBLISH'))
  ])));
}

class CommentsScreen extends StatefulWidget {final String postId;const CommentsScreen({super.key,required this.postId});@override State<CommentsScreen> createState()=>_CommentsScreenState();}
class _CommentsScreenState extends State<CommentsScreen>{final t=TextEditingController();Future<List<Map<String,dynamic>>> load()=>Supabase.instance.client.from('comments').select('*,profiles(username)').eq('post_id',widget.postId).order('created_at');Future<void> send()async{if(t.text.trim().isEmpty)return;await Supabase.instance.client.from('comments').insert({'post_id':widget.postId,'user_id':Supabase.instance.client.auth.currentUser!.id,'content':t.text.trim()});t.clear();setState((){});}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Comments')),body:Column(children:[Expanded(child:FutureBuilder(future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());return ListView(children:s.data!.map((x)=>ListTile(title:Text(x['profiles']?['username']??'User'),subtitle:Text(x['content']))).toList());})),Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:t,decoration:const InputDecoration(hintText:'Comment...'))),IconButton(onPressed:send,icon:const Icon(Icons.send))]))]));}

class RoomsScreen extends StatefulWidget{const RoomsScreen({super.key});@override State<RoomsScreen> createState()=>_RoomsScreenState();}
class _RoomsScreenState extends State<RoomsScreen>{Future<List<Map<String,dynamic>>> load()=>Supabase.instance.client.from('chat_rooms').select().order('created_at',ascending:false);
Future<void> create()async{final x=TextEditingController();await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Create Room'),content:TextField(controller:x),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancel')),ElevatedButton(onPressed:()async{await Supabase.instance.client.from('chat_rooms').insert({'name':x.text,'created_by':Supabase.instance.client.auth.currentUser!.id});if(mounted)Navigator.pop(c);setState((){});},child:const Text('Create'))]));}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Chat Rooms')),floatingActionButton:FloatingActionButton(onPressed:create,child:const Icon(Icons.add)),body:FutureBuilder(future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());return ListView(children:s.data!.map((r)=>ListTile(leading:const CircleAvatar(child:Icon(Icons.forum)),title:Text(r['name']),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ChatScreen(roomId:r['id'],name:r['name']))))).toList());}));}

class ChatScreen extends StatefulWidget{final String roomId,name;const ChatScreen({super.key,required this.roomId,required this.name});@override State<ChatScreen> createState()=>_ChatScreenState();}
class _ChatScreenState extends State<ChatScreen>{final t=TextEditingController();Future<void> send()async{if(t.text.trim().isEmpty)return;await Supabase.instance.client.from('messages').insert({'room_id':widget.roomId,'user_id':Supabase.instance.client.auth.currentUser!.id,'content':t.text.trim()});t.clear();}
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.name)),body:Column(children:[Expanded(child:StreamBuilder(stream:Supabase.instance.client.from('messages').stream(primaryKey:['id']).eq('room_id',widget.roomId).order('created_at'),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final me=Supabase.instance.client.auth.currentUser!.id;return ListView(children:s.data!.map((m)=>Align(alignment:m['user_id']==me?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.all(6),padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:m['user_id']==me?const Color(0xFF8B5CF6):const Color(0xFF22222D),borderRadius:BorderRadius.circular(12)),child:Text(m['content'])))).toList());})),Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:t,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Message'))),IconButton(onPressed:send,icon:const Icon(Icons.send))]))]));}

class GamesScreen extends StatelessWidget{const GamesScreen({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('FUNPLAY Games')),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(leading:const Text('🧠',style:TextStyle(fontSize:35)),title:const Text('Quiz Battle'),subtitle:const Text('Play quiz and earn score'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const QuizScreen())))),const Card(child:ListTile(leading:Text('🎮',style:TextStyle(fontSize:35)),title:Text('More games'),subtitle:Text('Game integrations can be added here')))]));}
class QuizScreen extends StatefulWidget{const QuizScreen({super.key});@override State<QuizScreen> createState()=>_QuizScreenState();}
class _QuizScreenState extends State<QuizScreen>{final qs=[['Capital of India?','Mumbai','Delhi','Kolkata','Chennai',1],['2 + 2 = ?','3','4','5','6',1],['Flutter language?','Dart','Java','Python','C++',0]];int q=0,score=0;void a(int x){if(x==qs[q][5])score+=10;if(q<qs.length-1)setState(()=>q++);else showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Game Over'),content:Text('Score: $score'),actions:[TextButton(onPressed:(){Navigator.pop(c);Navigator.pop(context);},child:const Text('Done'))]));}
@override Widget build(BuildContext c){final x=qs[q];return Scaffold(appBar:AppBar(title:Text('Quiz ${q+1}/${qs.length}')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Text(x[0] as String,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:30),for(int i=1;i<=4;i++)Padding(padding:const EdgeInsets.only(bottom:12),child:SizedBox(width:double.infinity,child:ElevatedButton(onPressed:()=>a(i-1),child:Text(x[i] as String)))),const Spacer(),Text('Score: $score')])));}}

class ProfileScreen extends StatelessWidget{const ProfileScreen({super.key});@override Widget build(BuildContext c){final u=Supabase.instance.client.auth.currentUser;return Scaffold(appBar:AppBar(title:const Text('Profile')),body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const CircleAvatar(radius:45,child:Icon(Icons.person,size:50)),const SizedBox(height:15),Text(u?.email??'',style:const TextStyle(fontSize:18)),const SizedBox(height:20),ElevatedButton(onPressed:()=>Supabase.instance.client.auth.signOut(),child:const Text('LOGOUT'))])));}}
